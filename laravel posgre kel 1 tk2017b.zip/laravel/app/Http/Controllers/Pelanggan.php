<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Pelanggan extends Controller
{
    function index() {
        return view('Pelanggan/index');
    }
    function form(){
        return view('Pelanggan/form');
    }

    function simpan(Request $minta){
        $name=$minta->name;
        $umur=$minta->umur;
        $ket=$minta->keterangan;
        $data=array(
            'namapelanggan'=>$name,
            'usia' =>$umur,
        );
        return view('Pelanggan/simpan', $data);
    }
}
