
<a href={{url('pelangganform')}}> Klik disini</a>
