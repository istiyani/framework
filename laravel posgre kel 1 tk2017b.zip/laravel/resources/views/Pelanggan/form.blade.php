

<form method="POST" action="{{url('pelanggan/simpan')}}">
    {{csrf_field()}}
    Nama : <input type="text" name="name"><br>
    Usia : <input type="number" name="umur">
    
    <button> klik</button>

</form>