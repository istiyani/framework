Nama : <?php echo e($namapelanggan); ?>

Umur : <?php echo e($usia); ?>


<?php if($usia < 12): ?>
    <?php ( $ket="Anak"); ?>
<?php elseif($usia < 17): ?>
        <?php ($ket="Remaja"); ?>
<?php elseif($usia < 22): ?>
            <?php ($ket="Dewasa muda"); ?>
<?php elseif($usia < 35): ?>
                <?php ($ket="Dewasa matang"); ?>
<?php elseif($usia > 35): ?>
                <?php ($ket="Tua"); ?>
<?php endif; ?>

Keterangan : <?php echo e($ket); ?>

<?php for($i=1; $i <= $usia; $i++): ?>
<?php echo e($i); ?>

<?php endfor; ?><?php /**PATH C:\xampp\htdocs\laravel\resources\views/Pelanggan/simpan.blade.php ENDPATH**/ ?>